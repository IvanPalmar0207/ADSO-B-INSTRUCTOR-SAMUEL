from django.contrib import admin
from facturasGestion.models import tb_metodoPago

# Register your models here.

admin.site.register(tb_metodoPago)