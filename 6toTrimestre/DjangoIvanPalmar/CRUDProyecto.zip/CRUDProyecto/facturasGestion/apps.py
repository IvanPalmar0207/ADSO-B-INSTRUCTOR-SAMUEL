from django.apps import AppConfig


class FacturasgestionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'facturasGestion'
