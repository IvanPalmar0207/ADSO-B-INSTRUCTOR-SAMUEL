from django.apps import AppConfig


class ReservagestionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reservaGestion'
