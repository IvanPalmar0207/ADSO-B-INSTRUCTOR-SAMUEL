from django.apps import AppConfig


class ReservasapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reservasAPI'
