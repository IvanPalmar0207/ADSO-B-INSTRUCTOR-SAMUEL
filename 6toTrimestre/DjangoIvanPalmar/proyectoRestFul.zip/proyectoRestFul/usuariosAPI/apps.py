from django.apps import AppConfig


class UsuariosapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'usuariosAPI'
